# Final-Year-Proj

Website name: Virus Inc.

Links
Github repository - https://github.com/DigSwine/Final-Year-Proj
Webpage URL - http://web.socem.plymouth.ac.uk/FYP/MWilsonSlider/Website/
Folder URL - \\CENT-5-534.uopnet.plymouth.ac.uk\FYP\MWilsonSlider
Database - Proj-mysql.uopnet.plymouth.ac.uk
Youtube Video - https://youtu.be/DNKnxeHjZxU

Defult Login Data

|------------|-----------|
|  Username  |  Password |
|------------|-----------|
|    test    |   test    |
|------------|-----------|


About Hacker Adversary
This game aim's to help students at the University of Plymouth to learn key terms and the components that build a virus, as well as some of the best types of virus’s that are used to cause harm to a network.

The Aim of the website
The project aim’s to be used by computer security students at the University of Plymouth, the main aim of the project is to offer support for students who have difficulty learning how to make virus’s by including a builder 
and a testing  section – this will be made to appear like a game to make the tool more inviting. As the virus was inspired by a game (Plague Inc.) the name I have chosen is “Hacker Adversary”. The project will be made on 
either a C# application hosted by Visual Studio or a Web Application. The Reason behind this project is to have a friendly tool to help students who are interested in virus’s and virus protection.

Instructions
Create a virus on the virus page and select Confirm once the virus had been created, the go to the game page and select what continent’s you want to start the virus in, then watch as the world’s networks starts to slowly 
become infected.

Rules
Hack the world to successfully infect each computer unit that had been sold in each continent.